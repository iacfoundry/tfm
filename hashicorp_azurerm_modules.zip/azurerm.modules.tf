module "azurerm_user_assigned_identity" {
  source = "./modules/hashicorp/azurerm/user_assigned_identity"

  azurerm_user_assigned_identity_data = var.azurerm_user_assigned_identity_data
}

