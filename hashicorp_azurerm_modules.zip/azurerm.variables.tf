variable "azurerm_user_assigned_identity_data" {
  default = {}
}

